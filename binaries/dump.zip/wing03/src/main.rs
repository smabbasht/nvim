use csv::Reader;
use tokio_postgres::{Error, NoTls};

#[tokio::main]
async fn main() -> Result<(), Error> {
    // Connect to the PostgreSQL database
    let (client, connection) = tokio_postgres::connect(
        "host=localhost port=8888 user=postgres password=postgres dbname=wingspan",
        NoTls,
    )
    .await?;

    // Spawn the connection to run concurrently with the client
    tokio::spawn(async move {
        if let Err(e) = connection.await {
            eprintln!("connection error: {}", e);
        }
    });

    // Open and read the CSV file
    let file_path = std::env::args().nth(1).unwrap();
    let mut rdr = Reader::from_path(file_path).unwrap();

    // Prepare the insert statement to match the table structure
    let insert_query = "INSERT INTO orders (Account,Symbol,SymbolSfx,Side,OrderId,ClOrdID,OrigClOrdID,OrderQty,Price,OrdType,TimeInForce,TransactTime,AvgPx,CumQty,ExecID,ExecRefID,ExecTransType,LastPx,LastShares,ExecType,LeavesQty,SecurityType,Text,ExDestination,Commission,ECNFee,CommType,SecurityIDSource,SecurityID,ExternalOrderId,ExpiryTime,DatedOrderId) 
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32)";

    // Loop through the CSV records and insert them into the database
    for result in rdr.records() {
        let record = result.unwrap();

        // Insert each record into the PostgreSQL database
        client
            .execute(
                insert_query,
                &[
                    &record[0].to_string(),
                    &record[1].to_string(),
                    &record[2].to_string(),
                    &record[3].to_string(),
                    &record[4].to_string(),
                    &record[5].to_string(),
                    &record[6].to_string(),
                    &record[7].to_string(),
                    &record[8].to_string(),
                    &record[9].to_string(),
                    &record[10].to_string(),
                    &record[11].to_string(),
                    &record[12].to_string(),
                    &record[13].to_string(),
                    &record[14].to_string(),
                    &record[15].to_string(),
                    &record[16].to_string(),
                    &record[17].to_string(),
                    &record[18].to_string(),
                    &record[19].to_string(),
                    &record[20].to_string(),
                    &record[21].to_string(),
                    &record[22].to_string(),
                    &record[23].to_string(),
                    &record[24].to_string(),
                    &record[25].to_string(),
                    &record[26].to_string(),
                    &record[27].to_string(),
                    &record[28].to_string(),
                    &record[29].to_string(),
                    &record[30].to_string(),
                    &record[31].to_string(),
                ],
            )
            .await?;
    }

    println!("CSV data successfully dumped into PostgreSQL!");
    Ok(())
}
